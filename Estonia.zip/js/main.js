$(function() {

	//nav

		$('.menu-icon').on('click', function () {
			$('.header__navBox').slideToggle();
		});

			// Menu Scroll to section	

	$(' a[href^="#"').click(function () {
		var target = $(this).attr('href');
		$('html, body').animate({
			 scrollTop: $(target).offset().top
		}, 1500);
		
		return false;
	});	

		// accord
		$(".accord__question").on("click", function () {
			$(this).next().stop(true).slideToggle(300);
			$(this).find('.image').fadeToggle(-100);
			$(this).find('.elips').fadeToggle(300);
			$(this).toggleClass('accordion_open');
			
		});

		// member2

		$('.addNewPerson').on('click', function(e){
			e.preventDefault();
			$('.member2').addClass('member-appear').toggle(700);
		});

		//Slider
	$('.slider').slick({
		vertical: true,
		slidesToShow: 4,
		slidesToScroll: 2,
	  prevArrow:'<i class="fal fa-angle-up"></i>',
		nextArrow:'<i class="fal fa-angle-down"></i>'
	});
});


		// Info
// $(function() {
// 	$(".fa-info-circle, .form__info").click(function(e) {
// 		e.preventDefault();
// 		$(this).parent().find('.info-block, .form__info').toggle(500);
		
// 	});

// });	
	
	

